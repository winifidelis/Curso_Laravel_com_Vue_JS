<?php $__env->startSection('content'); ?>
  <pagina tamanho="12">
    <painel titulo="Lista de Artigos">
      <tabela-lista v-bind:titulos="['teste','outros']"></tabela-lista>

    </painel>

  </pagina>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>